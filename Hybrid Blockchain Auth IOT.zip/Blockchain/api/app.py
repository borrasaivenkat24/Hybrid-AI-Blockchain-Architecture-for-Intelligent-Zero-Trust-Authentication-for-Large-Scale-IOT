import os, sys, time, warnings
import numpy as np
import joblib
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from web3 import Web3
import json

warnings.filterwarnings('ignore')

app = Flask(__name__)
CORS(app)

BASE     = os.path.dirname(os.path.abspath(__file__))
ROOT     = os.path.dirname(BASE)
MODEL_P  = os.path.join(ROOT, 'ml_engine', 'model', 'xgboost_model.pkl')
SCALER_P = os.path.join(ROOT, 'ml_engine', 'model', 'scaler.pkl')

model  = joblib.load(MODEL_P)
scaler = joblib.load(SCALER_P)

w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:7545'))

def load_contract(name):
    p = os.path.join(ROOT, 'build', 'contracts', f'{name}.json')
    with open(p) as f:
        art = json.load(f)
    net = list(art['networks'].keys())[-1]
    return w3.eth.contract(address=art['networks'][net]['address'], abi=art['abi'])

registry_contract = load_contract('DeviceRegistry')
auth_contract     = load_contract('AuthManager')
audit_contract    = load_contract('AuditLog')
ADMIN             = w3.eth.accounts[0]

print(" Starting Blockchain ML IoT Auth API...")
print(f"   Blockchain connected : {w3.is_connected()}")
print(f"   ML Model loaded      : XGBoost (115 features)")
print(f"   Admin Account        : {ADMIN}")

# ── In-Memory Store ──────────────────────────────────────
_stats        = {"total_authentications": 0, "total_anomalies": 0}
_auth_logs    = []
_device_trust = {}   # source of truth for trust scores

# ── Pages ────────────────────────────────────────────────
@app.route('/')
def dashboard():
    return render_template('dashboard.html')

@app.route('/admin')
def admin():
    return render_template('admin.html')

# ── /api/register ────────────────────────────────────────
@app.route('/api/register', methods=['POST'])
def register_device():
    global _auth_logs, _device_trust
    try:
        data   = request.json or {}
        addr   = data.get('device_address') or data.get('address')
        name   = data.get('device_name') or data.get('name', 'IoT-Device')
        d_hash = data.get('device_hash') or data.get('hash', f'hash_{addr[-6:]}')

        if not addr:
            _device_trust[addr] = _device_trust.get(addr, 100)
            return jsonify({"success": False, "error": "device_address required"}), 400

        # Init trust score at 100
        if addr not in _device_trust:
            _device_trust[addr] = 100

        try:
            already = registry_contract.functions.isRegistered(addr).call()
        except:
            already = False

        if not already:
            try:
                tx = registry_contract.functions.registerDevice(
                    addr, d_hash, name
                ).transact({'from': ADMIN, 'gas': 300000})
                w3.eth.wait_for_transaction_receipt(tx)
            except:
                try:
                    tx = registry_contract.functions.registerDevice(
                        addr, name, d_hash
                    ).transact({'from': ADMIN, 'gas': 300000})
                    w3.eth.wait_for_transaction_receipt(tx)
                except:
                    pass

        _auth_logs.append({
            "device_address": addr,
            "action":         "REGISTER",
            "ml_result":      "-",
            "auth_result":    "REGISTERED",
            "trust_score":    100,
            "confidence":     100,
            "timestamp":      int(time.time()),
            "device_name":    name
        })
        return jsonify({"success": True, "message": f"{name} registered", "address": addr})

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

# ── /api/authenticate ────────────────────────────────────
@app.route('/api/authenticate', methods=['POST'])
def authenticate():
    global _stats, _auth_logs, _device_trust
    try:
        data     = request.json or {}
        addr     = data.get('device_address') or data.get('address', '')
        features = data.get('features', [])

        # ML Prediction
        feat_arr    = np.array(features, dtype=float).reshape(1, -1)
        feat_scaled = scaler.transform(feat_arr)
        prediction  = int(model.predict(feat_scaled)[0])
        proba       = model.predict_proba(feat_scaled)[0]
        confidence  = round(float(max(proba)) * 100, 2)
        ml_result   = "ANOMALY" if prediction == 1 else "NORMAL"

        # ── Trust Score (Python memory — correct +5/-15) ──
        trust_before        = _device_trust.get(addr, 100)
        delta               = -15 if prediction == 1 else 5
        trust_after         = max(0, min(100, trust_before + delta))
        _device_trust[addr] = trust_after   # save

        # ── Update blockchain (best effort) ──────────────
        try:
            tx = auth_contract.functions.updateTrust(
                addr, prediction == 1
            ).transact({'from': ADMIN, 'gas': 200000})
            w3.eth.wait_for_transaction_receipt(tx)
        except:
            pass   # Python memory is source of truth

        # Auth result based on Python trust
        if trust_after < 20:
            auth_result = "DENIED - Revoked"
        elif trust_after < 50:
            auth_result = "STEP UP AUTH"
        else:
            auth_result = "GRANTED"

        # ── Log to AuditLog contract ──────────────────────
        try:
            tx2 = audit_contract.functions.logEvent(
                addr, ml_result, auth_result, trust_after
            ).transact({'from': ADMIN, 'gas': 200000})
            w3.eth.wait_for_transaction_receipt(tx2)
        except:
            pass

        # ── Update memory ─────────────────────────────────
        _stats["total_authentications"] += 1
        if prediction == 1:
            _stats["total_anomalies"] += 1

        _auth_logs.append({
            "device_address": addr,
            "action":         "AUTH",
            "ml_result":      ml_result,
            "auth_result":    auth_result,
            "trust_score":    trust_after,
            "confidence":     confidence,
            "timestamp":      int(time.time())
        })
        if len(_auth_logs) > 500:
            _auth_logs.pop(0)

        return jsonify({
            "success":     True,
            "ml_result":   ml_result,
            "auth_result": auth_result,
            "trust_score": trust_after,
            "confidence":  confidence
        })

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

# ── /api/revoke ──────────────────────────────────────────
@app.route('/api/revoke', methods=['POST'])
def revoke_device():
    global _device_trust
    try:
        addr = (request.json or {}).get('device_address')
        _device_trust[addr] = 0   # force revoke in memory too
        tx = registry_contract.functions.revokeDevice(addr).transact({'from': ADMIN, 'gas': 200000})
        w3.eth.wait_for_transaction_receipt(tx)
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

# ── /api/stats ───────────────────────────────────────────
@app.route('/api/stats', methods=['GET'])
def get_stats():
    unique  = set(l["device_address"] for l in _auth_logs if l.get("device_address"))
    active  = sum(1 for a in unique if _device_trust.get(a, 100) >= 20)
    revoked = sum(1 for a in unique if _device_trust.get(a, 100) < 20)
    return jsonify({
        "total_devices":         len(unique),
        "active_devices":        active,
        "revoked_devices":       revoked,
        "total_anomalies":       _stats["total_anomalies"],
        "total_authentications": _stats["total_authentications"],
        "success": True
    }), 200

# ── /api/devices ─────────────────────────────────────────
@app.route('/api/devices', methods=['GET'])
def get_devices():
    # Collect from auth logs
    seen = {}
    for log in _auth_logs:
        addr = log.get("device_address", "")
        if addr and addr not in seen:
            seen[addr] = log

    # Also add devices from _device_trust (registered but not yet authenticated)
    for addr, trust in _device_trust.items():
        if addr not in seen:
            seen[addr] = {
                "device_address": addr,
                "device_name":    f"IoT-{addr[2:6].upper()}",
                "trust_score":    trust,
                "action":         "REGISTER"
            }

    devices = []
    for addr, log in seen.items():
        trust     = _device_trust.get(addr, 100)
        is_active = trust >= 20

        auth_count = sum(1 for l in _auth_logs
                         if l.get("device_address") == addr and l.get("action") == "AUTH")
        last_log   = next((l for l in reversed(_auth_logs)
                           if l.get("device_address") == addr), None)
        name = log.get("device_name") or f"IoT-{addr[2:6].upper()}"

        devices.append({
            "device_address": addr,
            "device_name":    name,
            "is_active":      is_active,
            "trust_score":    trust,
            "auth_count":     auth_count,
            "last_seen":      last_log.get("timestamp") if last_log else None
        })
    return jsonify({"devices": devices, "success": True}), 200
# ── /api/logs ────────────────────────────────────────────
@app.route('/api/logs', methods=['GET'])
def get_logs():
    logs = [l for l in reversed(_auth_logs[-50:]) if l.get("action") == "AUTH"]
    return jsonify({"logs": logs, "success": True}), 200

# ── /api/status ──────────────────────────────────────────
@app.route('/api/status', methods=['GET'])
def status():
    return jsonify({"blockchain_connected": w3.is_connected(),
                    "ml_model": "XGBoost", "features": 115, "success": True})

# ── /api/clear ───────────────────────────────────────────
@app.route('/api/clear', methods=['POST'])
def clear_logs():
    global _stats, _auth_logs, _device_trust
    _auth_logs.clear()
    _device_trust.clear()
    _stats["total_authentications"] = 0
    _stats["total_anomalies"]       = 0
    return jsonify({"success": True})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
