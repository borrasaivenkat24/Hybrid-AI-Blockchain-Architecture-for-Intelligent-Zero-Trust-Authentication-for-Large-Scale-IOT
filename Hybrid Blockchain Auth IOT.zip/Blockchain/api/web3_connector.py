from web3 import Web3
import json
import os

# ─── Ganache Connection ───────────────────────────────────────
GANACHE_URL = "http://127.0.0.1:7545"
w3          = Web3(Web3.HTTPProvider(GANACHE_URL))

# ─── Contract Addresses ───────────────────────────────────────
REGISTRY_ADDRESS = "0xCfEB869F69431e42cdB54A4F4f105C19C080A601"
AUTH_ADDRESS     = "0x254dffcd3277C0b1660F6d42EFbB754edaBAbC2B"
AUDIT_ADDRESS    = "0xC89Ce4735882C9F0f0FE26686c53074E09B0D550"
ADMIN_ACCOUNT    = "0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1"

# ─── Load Contract ABIs ───────────────────────────────────────
BASE_PATH = os.path.dirname(os.path.dirname(__file__))

def load_abi(contract_name):
    abi_path = os.path.join(BASE_PATH, 'build', 'contracts',
                            f'{contract_name}.json')
    with open(abi_path) as f:
        return json.load(f)['abi']

# ─── Initialize Contracts ─────────────────────────────────────
registry_contract = w3.eth.contract(
    address = Web3.to_checksum_address(REGISTRY_ADDRESS),
    abi     = load_abi('DeviceRegistry')
)

auth_contract = w3.eth.contract(
    address = Web3.to_checksum_address(AUTH_ADDRESS),
    abi     = load_abi('AuthManager')
)

audit_contract = w3.eth.contract(
    address = Web3.to_checksum_address(AUDIT_ADDRESS),
    abi     = load_abi('AuditLog')
)

# ─── Helper: String to bytes32 ────────────────────────────────
def to_bytes32(text):
    return text.encode('utf-8').ljust(32, b'\x00')[:32]

# ─── Connection Check ─────────────────────────────────────────
def is_connected():
    return w3.is_connected()

# ─── Register Device ──────────────────────────────────────────
def register_device(device_address, device_hash):
    hash_bytes = to_bytes32(device_hash)
    tx = registry_contract.functions.registerDevice(
        Web3.to_checksum_address(device_address),
        hash_bytes
    ).transact({'from': ADMIN_ACCOUNT})
    return w3.eth.wait_for_transaction_receipt(tx)

# ─── Get Device Info ──────────────────────────────────────────
def get_device(device_address):
    return registry_contract.functions.getDevice(
        Web3.to_checksum_address(device_address)
    ).call()

# ─── Get All Devices ──────────────────────────────────────────
def get_all_devices():
    count = registry_contract.functions.getDeviceCount().call()
    device_addresses = []
    for i in range(count):
        addr = registry_contract.functions.deviceList(i).call()
        device_addresses.append(addr)
    return device_addresses
# ─── Update Trust Score ───────────────────────────────────────
def update_trust_score(device_address, score):
    tx = registry_contract.functions.updateTrustScore(
        Web3.to_checksum_address(device_address),
        int(score)
    ).transact({'from': ADMIN_ACCOUNT})
    return w3.eth.wait_for_transaction_receipt(tx)

# ─── Check Auth Status ────────────────────────────────────────
def authenticate_device(device_address):
    return auth_contract.functions.checkStatus(
        Web3.to_checksum_address(device_address)
    ).call()

# ─── Add Audit Log ────────────────────────────────────────────
def add_audit_log(device_address, action, result, score):
    tx = audit_contract.functions.addLog(
        Web3.to_checksum_address(device_address),
        action,
        result,
        int(score)
    ).transact({'from': ADMIN_ACCOUNT})
    return w3.eth.wait_for_transaction_receipt(tx)

# ─── Get Log Count ────────────────────────────────────────────
def get_log_count():
    return audit_contract.functions.getLogCount().call()

# ─── Get Recent Logs ──────────────────────────────────────────
def get_recent_logs(count=10):
    return audit_contract.functions.getRecentLogs(count).call()

# ─── Connection Test ──────────────────────────────────────────
if __name__ == "__main__":
    if w3.is_connected():
        print(" Connected to Ganache successfully!")
        print(f"   Block number : {w3.eth.block_number}")
        print(f"   Admin balance: {w3.eth.get_balance(ADMIN_ACCOUNT)} wei")
    else:
        print(" Connection failed — is Ganache running?")
