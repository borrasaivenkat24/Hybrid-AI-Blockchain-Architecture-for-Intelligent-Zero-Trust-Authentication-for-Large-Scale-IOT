const DeviceRegistry = artifacts.require("DeviceRegistry");
const AuthManager    = artifacts.require("AuthManager");
const AuditLog       = artifacts.require("AuditLog");

module.exports = async function(deployer) {

  // Step 1 — Deploy DeviceRegistry first
  await deployer.deploy(DeviceRegistry);
  const registry = await DeviceRegistry.deployed();
  console.log(" DeviceRegistry deployed at:", registry.address);

  // Step 2 — Deploy AuthManager with registry address
  await deployer.deploy(AuthManager, registry.address);
  const auth = await AuthManager.deployed();
  console.log(" AuthManager deployed at:", auth.address);

  // Step 3 — Deploy AuditLog
  await deployer.deploy(AuditLog);
  const audit = await AuditLog.deployed();
  console.log(" AuditLog deployed at:", audit.address);

  console.log("\n All contracts deployed successfully!");
  console.log(" Contract Addresses:");
  console.log("   DeviceRegistry :", registry.address);
  console.log("   AuthManager    :", auth.address);
  console.log("   AuditLog       :", audit.address);
};
