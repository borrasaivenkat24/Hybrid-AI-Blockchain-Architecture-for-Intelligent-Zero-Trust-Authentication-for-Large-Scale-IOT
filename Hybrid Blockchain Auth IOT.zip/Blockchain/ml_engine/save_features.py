import joblib
import pandas as pd

# Get feature names from one raw CSV file
df = pd.read_csv('dataset/1.benign.csv', nrows=1)
feature_names = [col for col in df.columns if col != 'label']

# Save
joblib.dump(feature_names, 'ml_engine/model/feature_names.pkl')

print(f"  feature_names.pkl saved!")
print(f"   Total features : {len(feature_names)}")
print(f"   Sample features: {feature_names[:5]}")
