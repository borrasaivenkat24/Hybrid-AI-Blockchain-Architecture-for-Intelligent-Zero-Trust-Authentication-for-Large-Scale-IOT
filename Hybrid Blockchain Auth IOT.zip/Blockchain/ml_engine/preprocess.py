import pandas as pd
import numpy as np
import os
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import joblib
import warnings
warnings.filterwarnings('ignore')

# ─── Configuration ────────────────────────────────────────────
DATASET_PATH = os.path.join(os.path.dirname(__file__), '..', 'dataset')
SAMPLES_PER_FILE = 5000   # Samples from each file (keeps dataset manageable)
RANDOM_STATE = 42

# ─── File Mapping ─────────────────────────────────────────────
BENIGN_FILES = [f"{i}.benign.csv" for i in range(1, 10)]

ATTACK_FILES = [
    "1.mirai.ack.csv", "1.mirai.scan.csv", "1.mirai.syn.csv",
    "1.mirai.udp.csv", "1.gafgyt.combo.csv", "1.gafgyt.tcp.csv",
    "2.mirai.ack.csv", "2.mirai.syn.csv", "2.gafgyt.combo.csv",
    "3.gafgyt.combo.csv", "3.gafgyt.tcp.csv", "3.gafgyt.udp.csv",
    "4.mirai.syn.csv", "4.mirai.udp.csv", "4.gafgyt.junk.csv",
    "5.mirai.syn.csv", "5.gafgyt.combo.csv", "5.gafgyt.tcp.csv",
    "6.mirai.udp.csv", "6.gafgyt.udp.csv", "6.gafgyt.scan.csv",
    "7.gafgyt.combo.csv", "7.gafgyt.tcp.csv", "7.gafgyt.udp.csv",
    "8.mirai.syn.csv", "8.mirai.udp.csv", "8.gafgyt.combo.csv",
    "9.mirai.syn.csv", "9.mirai.udp.csv", "9.gafgyt.combo.csv",
]

# ─── Load and Sample Files ─────────────────────────────────────
def load_and_sample(file_list, label, samples_per_file):
    frames = []
    for fname in file_list:
        fpath = os.path.join(DATASET_PATH, fname)
        if not os.path.exists(fpath):
            print(f"  ⚠ Skipping (not found): {fname}")
            continue
        try:
            df = pd.read_csv(fpath)
            df = df.sample(min(samples_per_file, len(df)),
                           random_state=RANDOM_STATE)
            df['label'] = label
            frames.append(df)
            print(f"  ✅ Loaded {len(df)} rows from {fname}")
        except Exception as e:
            print(f"  ❌ Error loading {fname}: {e}")
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()

# ─── Main Preprocessing Pipeline ──────────────────────────────
def preprocess():
    print("\n📦 Loading Benign Traffic (label=0)...")
    benign_df = load_and_sample(BENIGN_FILES, label=0, samples_per_file=SAMPLES_PER_FILE)

    print("\n⚠️  Loading Attack Traffic (label=1)...")
    attack_df = load_and_sample(ATTACK_FILES, label=1, samples_per_file=SAMPLES_PER_FILE)

    print("\n🔀 Combining and Shuffling Dataset...")
    df = pd.concat([benign_df, attack_df], ignore_index=True)
    df = df.sample(frac=1, random_state=RANDOM_STATE).reset_index(drop=True)

    print(f"\n📊 Dataset Shape     : {df.shape}")
    print(f"   Benign samples   : {len(df[df['label'] == 0])}")
    print(f"   Attack samples   : {len(df[df['label'] == 1])}")
    print(f"   Missing values   : {df.isnull().sum().sum()}")

    # ─── Handle Missing Values ────────────────────────────────
    df.fillna(df.median(numeric_only=True), inplace=True)

    # ─── Separate Features and Labels ─────────────────────────
    X = df.drop('label', axis=1).select_dtypes(include=[np.number])
    y = df['label']

    # ─── Scale Features ───────────────────────────────────────
    print("\n⚙️  Scaling features...")
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # ─── Train-Test Split ─────────────────────────────────────
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
    )

    print(f"\n✅ Train set size : {X_train.shape}")
    print(f"✅ Test set size  : {X_test.shape}")

    # ─── Save Processed Data ──────────────────────────────────
    print("\n💾 Saving processed data...")
    output_dir = os.path.join(os.path.dirname(__file__), 'model')
    os.makedirs(output_dir, exist_ok=True)

    joblib.dump(X_train, os.path.join(output_dir, 'X_train.pkl'))
    joblib.dump(X_test,  os.path.join(output_dir, 'X_test.pkl'))
    joblib.dump(y_train, os.path.join(output_dir, 'y_train.pkl'))
    joblib.dump(y_test,  os.path.join(output_dir, 'y_test.pkl'))
    joblib.dump(scaler,  os.path.join(output_dir, 'scaler.pkl'))

    print("\n🎉 Preprocessing Complete!")
    print(f"   Files saved in: ml_engine/model/")

if __name__ == "__main__":
    preprocess()
