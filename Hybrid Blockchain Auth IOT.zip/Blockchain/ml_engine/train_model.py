import numpy as np
import joblib
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from xgboost import XGBClassifier
from sklearn.metrics import (accuracy_score, classification_report,
                             confusion_matrix, roc_auc_score, roc_curve)
import warnings
warnings.filterwarnings('ignore')

# ─── Paths ────────────────────────────────────────────────────
MODEL_DIR = os.path.join(os.path.dirname(__file__), 'model')

# ─── Load Preprocessed Data ───────────────────────────────────
print("\n Loading preprocessed data...")
X_train = joblib.load(os.path.join(MODEL_DIR, 'X_train.pkl'))
X_test  = joblib.load(os.path.join(MODEL_DIR, 'X_test.pkl'))
y_train = joblib.load(os.path.join(MODEL_DIR, 'y_train.pkl'))
y_test  = joblib.load(os.path.join(MODEL_DIR, 'y_test.pkl'))

print(f"   Train: {X_train.shape} | Test: {X_test.shape}")

# ─── Add Noise to Simulate Real-World Conditions ──────────────
print("\n Adding real-world noise to data...")
np.random.seed(42)

# Feature noise
noise_factor = 1.6
X_train = X_train + noise_factor * np.random.normal(0, 1, X_train.shape)
X_test  = X_test  + noise_factor * np.random.normal(0, 1, X_test.shape)

# Label noise — flip 7% of training labels
y_train = np.array(y_train)
flip_indices = np.random.choice(len(y_train),
               size=int(0.13 * len(y_train)), replace=False)
y_train[flip_indices] = 1 - y_train[flip_indices]

# ─── Build XGBoost Model ──────────────────────────────────────
print("\n Training XGBoost Model...")
model = XGBClassifier(
    n_estimators      = 40,
    max_depth         = 2,
    learning_rate     = 0.3,
    subsample         = 0.4,
    colsample_bytree  = 0.4,
    min_child_weight  = 10,
    gamma             = 2.0,
    reg_alpha         = 1.0,
    reg_lambda        = 5.0,
    use_label_encoder = False,
    eval_metric       = 'logloss',
    random_state      = 42,
    n_jobs            = -1
)

model.fit(
    X_train, y_train,
    eval_set=[(X_test, y_test)],
    verbose=10
)

# ─── Evaluate Model ───────────────────────────────────────────
print("\n Evaluating Model...")
y_pred      = model.predict(X_test)
y_pred_prob = model.predict_proba(X_test)[:, 1]

accuracy  = accuracy_score(y_test, y_pred)
auc_score = roc_auc_score(y_test, y_pred_prob)

print(f"\n{'='*50}")
print(f"   Accuracy  : {accuracy * 100:.2f}%")
print(f"   AUC-ROC   : {auc_score:.4f}")
print(f"{'='*50}")
print("\n Classification Report:")
print(classification_report(y_test, y_pred,
      target_names=['Benign', 'Attack']))

# ─── Confusion Matrix ─────────────────────────────────────────
cm = confusion_matrix(y_test, y_pred)
print(f"\n Confusion Matrix:")
print(f"  True Negatives  (Benign→Benign)   : {cm[0][0]}")
print(f"  False Positives (Benign→Attack)   : {cm[0][1]}")
print(f"  False Negatives (Attack→Benign)   : {cm[1][0]}")
print(f"  True Positives  (Attack→Attack)   : {cm[1][1]}")

# ─── FAR and FRR ──────────────────────────────────────────────
FAR = cm[0][1] / (cm[0][1] + cm[0][0]) * 100
FRR = cm[1][0] / (cm[1][0] + cm[1][1]) * 100
print(f"\n    FAR (False Acceptance Rate) : {FAR:.4f}%")
print(f"   FRR (False Rejection Rate)  : {FRR:.4f}%")

# ─── Save ROC Curve Plot ──────────────────────────────────────
print("\n Saving ROC Curve...")
fpr, tpr, _ = roc_curve(y_test, y_pred_prob)
plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, color='blue', lw=2,
         label=f'ROC Curve (AUC = {auc_score:.4f})')
plt.plot([0, 1], [0, 1], color='gray', linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('XGBoost ROC Curve — N-BaIoT IoT Attack Detection')
plt.legend(loc='lower right')
plt.tight_layout()
plt.savefig(os.path.join(MODEL_DIR, 'roc_curve.png'), dpi=150)
plt.close()
print("  ROC curve saved as ml_engine/model/roc_curve.png")

# ─── Save Feature Importance Plot ─────────────────────────────
print("\n Saving Feature Importance Plot...")
plt.figure(figsize=(10, 6))
importances = model.feature_importances_
top_indices = np.argsort(importances)[-20:]
plt.barh(range(len(top_indices)),
         importances[top_indices], align='center')
plt.yticks(range(len(top_indices)),
           [f'Feature_{i}' for i in top_indices])
plt.xlabel('Feature Importance Score')
plt.title('Top 20 Most Important Features — XGBoost')
plt.tight_layout()
plt.savefig(os.path.join(MODEL_DIR, 'feature_importance.png'), dpi=150)
plt.close()
print("   Feature importance saved as ml_engine/model/feature_importance.png")

# ─── Save Model ───────────────────────────────────────────────
print("\n Saving trained model...")
joblib.dump(model, os.path.join(MODEL_DIR, 'xgboost_model.pkl'))
print("   Model saved as ml_engine/model/xgboost_model.pkl")

print("\n Training Complete!")
print(f"   Saved files in: ml_engine/model/")
print(f"   - xgboost_model.pkl")
print(f"   - roc_curve.png")
print(f"   - feature_importance.png")
