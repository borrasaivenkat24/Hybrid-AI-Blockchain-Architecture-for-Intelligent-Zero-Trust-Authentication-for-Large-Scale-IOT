import requests, random, time, os, warnings
import pandas as pd
import numpy as np

warnings.filterwarnings('ignore')

API      = "http://127.0.0.1:5000/api"
ROOT     = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATASET  = os.path.join(ROOT, 'dataset')
INTERVAL = 10

# ── Default devices (auto-registered on startup) ─────────
DEFAULT_DEVICES = [
    {"address": "0x22d491Bde2303f2f43325Dce3a4df89D6D64De4B", "name": "Smart-Sensor-1",    "hash": "hash_smart_sensor_1"},
    {"address": "0xd03ea8624C8C5987236FBe9c6B6Df7c823b36f4B", "name": "Smart-Sensor-2",    "hash": "hash_smart_sensor_2"},
    {"address": "0x95cED938F7991cd0dFa5Bf7C8B36D08c52ABcD1", "name": "Smart-Camera-1",    "hash": "hash_smart_camera_1"},
    {"address": "0x3E5e9111Ae8eB78Fe199F4a321D9F9BcA8673De5", "name": "Smart-Lock-1",      "hash": "hash_smart_lock_1"},
    {"address": "0x28a8746e75304c0780b53D7c9649cBdB4F04FC5D", "name": "Smart-Thermostat-1","hash": "hash_smart_thermostat_1"},
    {"address": "0x1dF62f291b2E969fB0849d99D9Ce41e2F137006e", "name": "Smart-Bulb-1",      "hash": "hash_smart_bulb_1"},
    {"address": "0x610Bb1573d1046FCb8A70Bbbd395754cD57C2b60", "name": "Smart-Bulb-2",      "hash": "hash_smart_bulb_2"},
    {"address": "0x855FA758c77D68a04990E992aA4dcdeF899F654b", "name": "Smart-Fridge-1",    "hash": "hash_smart_fridge_1"},
    {"address": "0xfA2435Eacf10Ca62ae6787ba2fB044f8733Ee843", "name": "Smart-TV-1",        "hash": "hash_smart_tv_1"},
    {"address": "0x64E078A8Aa15A41B85890265648e965De686baE",  "name": "Smart-Speaker-1",   "hash": "hash_smart_speaker_1"},
    {"address": "0x2F560290FEF1B3Ada194b6aA9c40aa71f8e95598", "name": "Smart-Doorbell-1",  "hash": "hash_smart_doorbell_1"},
    {"address": "0xf408f04F9b7691f7174FA2bb73ad6d45fD5d3CBe", "name": "Smart-AC-1",        "hash": "hash_smart_ac_1"},
    {"address": "0x66FC3AfB2d09dFDd60498DE2B85f379F31E77B83", "name": "Smart-Meter-1",     "hash": "hash_smart_meter_1"},
    {"address": "0xD7De14091B4e2b95B21f1f71d8A17B0d1767D4B7", "name": "Smart-Router-1",    "hash": "hash_smart_router_1"},
    {"address": "0x9dA5b1A4172B3a7E2A4Fe4aB2a3cB1fE5E7cD2B1", "name": "Smart-Watch-1",    "hash": "hash_smart_watch_1"},
]

print("   Loading real traffic samples from dataset...")

benign_df = None
benign_path = os.path.join(DATASET, '1.benign.csv')
if os.path.exists(benign_path):
    benign_df = pd.read_csv(benign_path)
    print(f"    Benign traffic: {len(benign_df)} rows, {len(benign_df.columns)} features")

attack_dfs = []
for f in ['1.mirai.ack.csv','1.mirai.scan.csv','1.mirai.syn.csv','1.gafgyt.tcp.csv','1.gafgyt.udp.csv']:
    p = os.path.join(DATASET, f)
    if os.path.exists(p):
        df = pd.read_csv(p)
        attack_dfs.append(df)
        print(f"    {f}: {len(df)} rows")

attack_df = pd.concat(attack_dfs) if attack_dfs else None

if benign_df is not None:
    FEATURES = list(benign_df.columns)
elif attack_df is not None:
    FEATURES = list(attack_df.columns)
else:
    print("   ❌ No dataset found!")
    exit(1)

print(f"   Features : {len(FEATURES)}")

def get_sample(is_attack):
    try:
        df  = attack_df if (is_attack and attack_df is not None) else benign_df
        row = df.sample(1).iloc[0]
        vals = []
        for col in FEATURES:
            try:
                v = float(row[col])
                vals.append(0.0 if (np.isnan(v) or np.isinf(v)) else v)
            except:
                vals.append(0.0)
        return vals
    except:
        return [0.0] * len(FEATURES)

def get_active_devices():
    """
    Fetch device list from API automatically.
    Returns merged list of default + any new devices added from Admin Panel.
    """
    try:
        r = requests.get(f"{API}/devices", timeout=5)
        if r.status_code == 200:
            api_devices = r.json().get("devices", [])
            # Build set of known addresses from API
            api_addresses = {d["device_address"].lower() for d in api_devices}

            # Start with default devices
            merged = list(DEFAULT_DEVICES)
            merged_addresses = {d["address"].lower() for d in merged}

            # Add any NEW devices registered from Admin Panel
            for d in api_devices:
                addr = d["device_address"]
                if addr.lower() not in merged_addresses:
                    merged.append({
                        "address": addr,
                        "name":    d.get("device_name", f"IoT-{addr[2:6].upper()}"),
                        "hash":    f"hash_{addr[-6:].lower()}"
                    })
                    print(f"    New device detected: {d.get('device_name', addr[:10])}")

            return merged
    except:
        pass
    return DEFAULT_DEVICES   # fallback to defaults if API unreachable

def register_devices(devices):
    print(f"\n Registering {len(devices)} IoT Devices on Blockchain...")
    for i, dev in enumerate(devices):
        try:
            r = requests.post(f"{API}/register", json={
                "device_address": dev["address"],
                "device_name":    dev["name"],
                "device_hash":    dev["hash"]
            }, timeout=10)
            status = "" if r.status_code == 200 else "❌"
            print(f"  {status} Device {i+1:>2} → {dev['name']}")
        except Exception as e:
            print(f"    Device {i+1:>2} → {dev['name']}: {e}")

def run_round(round_num, devices):
    ts = time.strftime("%H:%M:%S")
    print(f"\n{'─'*70}")
    print(f" Round {round_num} — {ts} — {len(devices)} devices")
    print(f"{'─'*70}")

    for dev in devices:
        # Skip revoked devices
        is_attack = random.random() < 0.30
        label     = "ATTACK" if is_attack else "NORMAL"
        features  = get_sample(is_attack)

        try:
            r = requests.post(f"{API}/authenticate", json={
                "device_address": dev["address"],
                "features":       features
            }, timeout=15)

            if r.status_code == 200:
                data        = r.json()
                ml_result   = data.get("ml_result",  "?")
                trust       = data.get("trust_score", "?")
                confidence  = data.get("confidence",  "?")
                auth_result = data.get("auth_result", "?")
                correct     = "✅" if (ml_result == "ANOMALY") == is_attack else "❌"
                print(f"  {dev['name']:<22} | Sent:{label:<7} | ML:{ml_result:<8} | "
                      f"Trust:{str(trust):>4}% | Conf:{confidence:>6}% | {auth_result} {correct}")
            else:
                print(f"  {dev['name']:<22} | HTTP {r.status_code}")

        except Exception as e:
            print(f"  {dev['name']:<22} | ERROR: {str(e)[:40]}")

# ── Main ─────────────────────────────────────────────────
print(f"\n IoT Device Simulator Starting...")
print(f"   Features : {len(FEATURES)}")
print(f"   Interval : {INTERVAL}s per round")

# Register all default devices
register_devices(DEFAULT_DEVICES)
print("\n  Starting simulation (Ctrl+C to stop)...")

round_num = 1
while True:
    try:
        # ── Auto-detect new devices every round ──────────
        devices = get_active_devices()

        run_round(round_num, devices)
        round_num += 1
        time.sleep(INTERVAL)

    except KeyboardInterrupt:
        print("\n\n Simulator stopped.")
        break
    except Exception as e:
        print(f"\n Round error: {e}")
        time.sleep(5)
